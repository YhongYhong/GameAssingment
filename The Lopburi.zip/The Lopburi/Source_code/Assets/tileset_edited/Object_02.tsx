<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Object_02" tilewidth="64" tileheight="64" tilecount="4" columns="2">
 <image source="../../../../15 - fixes audio/graphics/objects/03.png" width="128" height="128"/>
</tileset>
