<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tf_jungle_tileset" tilewidth="64" tileheight="64" tilecount="25" columns="5">
 <image source="../tileset/rpgmaker/tf_jungle_tileset.png" width="352" height="336"/>
</tileset>
