<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="TilesetFloor" tilewidth="32" tileheight="32" tilecount="143" columns="11">
 <image source="../tileset/NinjaAdventure/Backgrounds/Tilesets/TilesetFloor.png" width="352" height="417"/>
</tileset>
