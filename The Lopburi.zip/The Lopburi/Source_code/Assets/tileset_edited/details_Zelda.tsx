<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="details_Zelda" tilewidth="64" tileheight="64" tilecount="80" columns="16">
 <image source="../tileset/Zelda/tilemap/details.png" width="1024" height="320"/>
</tileset>
