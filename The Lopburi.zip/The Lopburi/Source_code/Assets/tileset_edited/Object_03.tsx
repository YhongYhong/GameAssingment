<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Object_03" tilewidth="64" tileheight="64" tilecount="2" columns="1">
 <image source="../../../../15 - fixes audio/graphics/objects/14.png" width="64" height="128"/>
</tileset>
